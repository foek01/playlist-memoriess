window.env = {
    "PROTOCOL_DEV": "http",
    "PROTOCOL_PRD": "https",
    "NODE_ENV": "development",
    "REDIRECT_DEV": "http://localhost:3000",
    "REDIRECT_PRD": "https://lucasbos.dev/erwin",
    "BACKEND_BASE_DEV": "localhost:5000",
    "BACKEND_BASE_PRD": "api.lucasbos.dev",
    "SPOTIFY_CLIENT_ID": "8a534d9a1d1742dfacf9172ee89c29cb",
    "SPOTIFY_CLIENT_SECRET": "2087c55c839749eb9dc694b7f7b3c625",
    "BUCKET_NAME": "playlist-memories"
  };